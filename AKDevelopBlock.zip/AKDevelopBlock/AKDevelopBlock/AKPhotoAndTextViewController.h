//
//  AKPhotoAndTextViewController.h
//  AKDevelopBlock
//
//  Created by 李亚坤 on 2017/5/31.
//  Copyright © 2017年 Kuture. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AKPhotoAndTextViewController : UITableViewController

@end
