//
//  AKImgResizeOne.h
//  AKDevelopBlock
//
//  Created by Kuture on 2017/6/11.
//  Copyright © 2017年 Kuture. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AKImgResizeOne : UITableViewController

@end
