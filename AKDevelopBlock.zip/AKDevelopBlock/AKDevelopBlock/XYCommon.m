//
//  XYCommon.m
//  PieChart
//
//  Created by GMY on 17/6/1.
//  Copyright © 2017年 com.gmy. All rights reserved.
//

#import "XYCommon.h"

@implementation XYCommon

CGFloat const CenterTitleWidth = 70;

CGFloat const AmountWidth = 70;

CGFloat const AmountHeight = 22;

@end
