//
//  AKNewHotModel.m
//  AKIRPManage
//
//  Created by 李亚坤 on 2016/11/4.
//  Copyright © 2016年 李亚坤. All rights reserved.
//

#import "AKNewHotModel.h"

@implementation AKNewHotModel

@end
