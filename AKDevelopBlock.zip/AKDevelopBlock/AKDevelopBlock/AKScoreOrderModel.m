//
//  AKScoreOrderModel.m
//  AKIRPManage
//
//  Created by 李亚坤 on 2016/10/18.
//  Copyright © 2016年 李亚坤. All rights reserved.
//

#import "AKScoreOrderModel.h"

@implementation AKScoreOrderModel

@end
