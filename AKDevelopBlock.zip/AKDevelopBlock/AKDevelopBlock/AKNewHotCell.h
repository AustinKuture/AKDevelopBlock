//
//  AKNewHotCell.h
//  AKIRPManage
//
//  Created by 李亚坤 on 2016/10/18.
//  Copyright © 2016年 李亚坤. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AKNewHotCell : UITableViewCell

@property (nonatomic,strong) UIImageView *picView;
@property (nonatomic,strong) UILabel *projName;
@property (nonatomic,strong) UILabel *partment;
@property (nonatomic,strong) UILabel *person;
@property (nonatomic,strong) UILabel *timeLabel;

@end
