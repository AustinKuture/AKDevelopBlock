//
//  AKSearchResultController.h
//  AKDevelopBlock
//
//  Created by 李亚坤 on 2017/6/18.
//  Copyright © 2017年 Kuture. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AKSearchResultController : UITableViewController

@property (nonatomic,copy) NSString *searchWords;

@end
