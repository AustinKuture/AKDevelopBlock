//
//  AKWeatherView.h
//  AKIRPManage
//
//  Created by 李亚坤 on 16/9/26.
//  Copyright © 2016年 李亚坤. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AKWeatherView : UIView

@property (nonatomic,copy) NSString *WeatherSTR;
@property (nonatomic,copy) NSString *cityName;
@property (nonatomic,copy) NSString *detailLocation;

@end
