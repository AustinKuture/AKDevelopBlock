//
//  AKGuessCell.h
//  AKIRPManage
//
//  Created by 李亚坤 on 2016/10/20.
//  Copyright © 2016年 李亚坤. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AKGuessCell : UITableViewCell

@property (nonatomic,strong) UILabel *projName;
@property (nonatomic,strong) UILabel *partment;
@property (nonatomic,strong) UILabel *person;
@property (nonatomic,strong) UILabel *timeLabel;

@end
